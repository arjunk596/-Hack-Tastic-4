from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login
from django.contrib.auth.models import User
from .models import Profile, Skill, MatchRequest, Message, Notification
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import ProfileForm

def register(request):
    """
    Handles the user registration process.
    If the request method is POST, it processes the form data and creates a new user.
    If the request method is GET, it renders the registration form.
    """
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('dashboard')
    else:
        form = UserCreationForm()
    return render(request, 'users/register.html', {'form': form})

@login_required
def home(request):
    """
    Renders the home template for the logged-in user.
    This is the main entry point of the application,
    where the user can access the various features.
    """
    return render(request, 'users/home.html')

@login_required
def respond_to_request(request, notification_id):
    """
    Handles the user's response to a match request.
    If the request method is POST, it updates the status of the Notification
    object based on the user's chosen action (accept or decline).
    """
    notification = get_object_or_404(Notification, id=notification_id, recipient=request.user)
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'accept':
            notification.status = 'accepted'
            notification.is_read = True
            notification.save()
            return redirect('profile', user_id=notification.sender.id)
        elif action == 'decline':
            notification.status = 'declined'
            notification.is_read = True
            notification.save()
            return redirect('notifications')
    return render(request, 'users/respond_to_request.html', {'notification': notification})

@login_required
def received_requests(request):
    """
    Displays the match requests received by the logged-in user.
    """
    received_requests = MatchRequest.objects.filter(receiver=request.user, status='pending')
    return render(request, 'users/received_requests.html', {'received_requests': received_requests})

@login_required
def dashboard(request):
    """
    Renders the dashboard template for the logged-in user.
    This is the main dashboard where the user can see an overview of their activities.
    """
    profile, created = Profile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        profile_form = ProfileForm(request.POST, instance=profile)
        if profile_form.is_valid():
            profile_form.save()
            messages.success(request, "Profile updated successfully.")
            return redirect('dashboard')
    else:
        profile_form = ProfileForm(instance=profile)
    
    user_skills = Skill.objects.filter(user=request.user)
    return render(request, 'users/dashboard.html', {'profile_form': profile_form, 'user_skills': user_skills})

@login_required
def add_skill(request):
    """
    Handles the addition of a new skill by the user.
    If the request method is POST, it processes the form data and creates a new skill.
    If the request method is GET, it renders the add skill form.
    """
    if request.method == 'POST':
        skill_name = request.POST.get('skill_name')
        level = request.POST.get('level')
        if skill_name and level:
            Skill.objects.create(user=request.user, skill_name=skill_name, level=level)
            messages.success(request, "Skill added successfully.")
            return redirect('dashboard')
        else:
            messages.error(request, "Please enter a valid skill name and level.")
    return render(request, 'users/add_skill.html')

@login_required
def match_users(request):
    """
    Handles the matching of users based on their skills.
    This view will find users with matching skills and create match requests.
    """
    matches = None
    if request.method == 'POST':
        skill_name = request.POST.get('skill_name')
        if skill_name:
            matches = Skill.objects.filter(skill_name__icontains=skill_name).exclude(user=request.user)
            if not matches:
                messages.info(request, "No matches found.")
        else:
            messages.error(request, "Please enter a valid skill name.")
    return render(request, 'users/match_users.html', {'matches': matches})

@login_required
def request_match(request):
    """
    Handles the creation of a match request by the user.
    If the request method is POST, it processes the form data and creates a new match request.
    """
    if request.method == 'POST':
        skill_id = request.POST.get('skill_id')
        skill = get_object_or_404(Skill, id=skill_id)
        match_request = MatchRequest.objects.create(
            sender=request.user,
            receiver=skill.user,
            skill=skill,
            status='pending'
        )
        Notification.objects.create(
            user=skill.user,
            message=f"{request.user.username} wants to collaborate with you on {skill.skill_name}.",
            notification_type='received'
        )
        Notification.objects.create(
            user=request.user,
            message=f"You have sent a collaboration request to {skill.user.username} for {skill.skill_name}.",
            notification_type='sent'
        )
        messages.success(request, f"You have sent a match request for {skill.skill_name}.")
        return redirect('match_users')
    return redirect('match_users')

@login_required
def notifications(request):
    """
    Renders the notifications template for the logged-in user.
    This view will display all the notifications for the user.
    """
    sent_notifications = request.user.sent_notifications.all().order_by('-created_at')
    received_notifications = request.user.received_notifications.all().order_by('-created_at')
    return render(request, 'users/notifications.html', {
        'sent_notifications': sent_notifications,
        'received_notifications': received_notifications
    })

@login_required
def mark_notification_as_read(request, notification_id):
    """
    Marks a notification as read.
    """
    notification = get_object_or_404(Notification, id=notification_id, recipient=request.user)
    notification.is_read = True
    notification.save()
    return redirect('notifications')

@login_required
def chat(request, match_id):
    """
    Renders the chat template for the logged-in user.
    This view will display the chat messages for a specific match.
    """
    match = get_object_or_404(MatchRequest, id=match_id)
    if request.method == 'POST':
        message_content = request.POST.get('message')
        if message_content:
            Message.objects.create(
                sender=request.user,
                receiver=match.receiver if match.sender == request.user else match.sender,
                content=message_content,
                match=match
            )
            messages.success(request, "Message sent successfully.")
            return redirect('chat', match_id=match_id)
    chat_messages = Message.objects.filter(match=match).order_by('timestamp')
    return render(request, 'users/chat.html', {'match': match, 'chat_messages': chat_messages})

@login_required
def send_message(request):
    """
    Handles sending a message from one user to another.
    If the request method is POST, it processes the form data and creates a new message.
    """
    if request.method == 'POST':
        receiver_id = request.POST.get('receiver_id')
        content = request.POST.get('content')
        receiver = get_object_or_404(User, id=receiver_id)
        if content:
            Message.objects.create(
                sender=request.user,
                receiver=receiver,
                content=content
            )
            messages.success(request, "Message sent successfully.")
            return redirect('notifications')
        else:
            messages.error(request, "Please enter a valid message.")
    return render(request, 'users/send_message.html')

@login_required
def profile(request, user_id):
    """
    Renders the profile template for the specified user.
    This view will display the profile and skills of the specified user.
    """
    user_profile = get_object_or_404(Profile, user_id=user_id)
    user_skills = Skill.objects.filter(user=user_profile.user)
    return render(request, 'users/profile.html', {'profile': user_profile, 'skills': user_skills})