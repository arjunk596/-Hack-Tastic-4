from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from .models import Profile, Skill, Match
from django.contrib.auth.decorators import login_required 

# User Registration
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            Profile.objects.create(user=user)  # Create a profile for the user
            login(request, user)
            return redirect('dashboard')
    else:
        form = UserCreationForm()
    return render(request, 'users/register.html', {'form': form})

@login_required
def dashboard(request):
    return render(request, 'users/dashboard.html')  # Example dashboard page

# Dashboard
def dashboard(request):
    profile = Profile.objects.get(user=request.user)
    skills = Skill.objects.filter(user=request.user)
    return render(request, 'users/dashboard.html', {'profile': profile, 'skills': skills})

# Add Skill
def add_skill(request):
    if request.method == 'POST':
        skill_name = request.POST['skill_name']
        level = request.POST['level']
        description = request.POST['description']
        Skill.objects.create(user=request.user, skill_name=skill_name, level=level, description=description)
        return redirect('dashboard')
    return render(request, 'users/add_skill.html')

# Match Users
def match_users(request):
    if request.method == 'POST':
        skill_name = request.POST['skill_name']
        matches = Skill.objects.filter(skill_name__icontains=skill_name).exclude(user=request.user)
        return render(request, 'users/matches.html', {'matches': matches})
    return render(request, 'users/match_users.html')

# Video Call Link
def video_call(request):
    profile = Profile.objects.get(user=request.user)
    video_call_link = profile.video_call_link or "https://example.com/videocall"
    return render(request, 'users/video_call.html', {'video_call_link': video_call_link})
