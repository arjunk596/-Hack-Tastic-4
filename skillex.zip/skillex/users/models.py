from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import User

# Profile Model
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(blank=True, null=True)
    location = models.CharField(max_length=100, blank=True, null=True)
    video_call_link = models.URLField(blank=True, null=True)

    def __str__(self):
        return self.user.username

# Skill Model
class Skill(models.Model):
    LEVEL_CHOICES = [
        ('Beginner', 'Beginner'),
        ('Amateur', 'Amateur'),
        ('Pro', 'Pro'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    skill_name = models.CharField(max_length=100)
    level = models.CharField(max_length=20, choices=LEVEL_CHOICES)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.skill_name} ({self.user.username})"

# Match Model
class Match(models.Model):
    requester = models.ForeignKey(User, on_delete=models.CASCADE, related_name='requester')
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name='receiver')
    skill_name = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.requester.username} matched with {self.receiver.username} for {self.skill_name}"
